# Design System Specification: The Architectural Intelligence (AI) Framework

## 1. Overview & Creative North Star: "The Digital Curator"
This design system rejects the "SaaS-in-a-box" aesthetic. Our North Star is **The Digital Curator**: a philosophy that treats data as an exhibit and the interface as a silent, sophisticated gallery.

We move beyond standard dashboards by embracing **Intentional Asymmetry** and **Tonal Depth**. Instead of boxing data into rigid, outlined grids, we use breathing room and structural layering to guide the eye. The interface should feel less like software and more like a high-end technical publication—authoritative, surgically clean, and intellectually effortless.

---

## 2. Color & Surface Philosophy
The palette is rooted in technical precision. We use `primary` (#3525CD) not just as a brand mark, but as a functional beacon against a landscape of sophisticated neutrals.

### The "No-Line" Rule
**Strict Mandate:** Prohibit the use of 1px solid borders for sectioning or layout containment. 
Boundaries must be defined exclusively through background color shifts or tonal transitions. To separate a sidebar from a main content area, transition from `surface-container-low` (#F3F4F5) to `surface` (#F8F9FA). 

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—stacked sheets of fine paper or frosted glass.
- **Base Layer:** `surface` (#F8F9FA) for the primary application background.
- **Sectioning:** `surface-container-low` (#F3F4F5) for large structural areas (Sidebars, Utility bars).
- **Interactive Layers:** `surface-container-lowest` (#FFFFFF) for primary cards and data entry points to create a "lifted" feel against the gray base.
- **Nesting:** When placing a card within a section, use the tier logic: A `surface-container-highest` (#E1E3E4) small component inside a `surface-container-low` container creates natural focus without a single line of CSS border.

### The "Glass & Gradient" Rule
To signify "AI-powered" intelligence, floating elements (Modals, Popovers, Command Palettes) must use **Glassmorphism**:
- **Background:** `surface` with 80% opacity.
- **Effect:** `backdrop-blur: 20px`.
- **Signature Texture:** Use a subtle linear gradient on primary CTAs: `primary` (#3525CD) to `primary_container` (#4F46E5) at a 135-degree angle. This provides a "liquid" depth that flat hex codes lack.

---

## 3. Typography: The Editorial Scale
We pair the technical precision of **Inter** with the structural elegance of **Manrope** to create a high-contrast, editorial hierarchy.

- **Display & Headlines (Manrope):** Used for data storytelling. Large, bold weights convey authority. The wider tracking of Manrope feels "Technical-Premium."
- **Body & Labels (Inter):** Used for functional utility. Inter’s high x-height ensures readability in dense technical data.

**Hierarchy Intent:**
- `display-lg` (3.5rem): Used for "hero" metrics or AI-generated insights.
- `title-sm` (1rem): The workhorse for card headers and navigation labels.
- `label-sm` (0.6875rem): Uppercase with +5% letter spacing for metadata and "micro-copy" to maintain a technical, blueprint-like feel.

---

## 4. Elevation & Depth: Tonal Layering
Traditional shadows are often "dirty." We achieve depth through light and tone.

- **The Layering Principle:** Place a `surface-container-lowest` (#FFFFFF) element on top of a `surface-container` (#EDEEEF) background to create a "Natural Lift."
- **Ambient Shadows:** For floating elements (e.g., active dropdowns), use a multi-layered shadow:
  - `box-shadow: 0 10px 40px -10px rgba(25, 28, 29, 0.06);` 
  - The shadow color must be a tinted version of `on-surface` (#191C1D), never pure black.
- **The "Ghost Border" Fallback:** If a border is required for accessibility in complex data tables, use `outline_variant` at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons
- **Primary:** Gradient-filled (`primary` to `primary_container`), `xl` (0.75rem) roundedness. No border.
- **Secondary:** `surface-container-highest` background with `on-surface` text. No border.
- **Tertiary:** Pure text with `primary` color; icon suffix moves 2px on hover to indicate momentum.

### Cards & Data Containers
**Forbid divider lines.** Separate content using vertical whitespace (e.g., 24px or 32px gaps). Use a "gutter" of `surface-container-low` to separate grouped list items rather than a horizontal rule.

### Code Blocks
To honor the "technical" personality, code blocks must be a dark sanctuary within the light UI. Use `inverse_surface` (#2E3132) with `primary_fixed_dim` (#C3C0FF) for syntax highlighting. 

### Chips & Status Indicators
Use the `full` (9999px) roundedness scale. 
- **Status:** Use low-saturation backgrounds (`error_container`, `primary_fixed`) with high-saturation text (`on_error_container`, `on_primary_fixed_variant`). This ensures the UI doesn't look like a "Christmas tree" of bright colors.

### Sidebar Navigation
The sidebar should feel like a part of the architecture, not a menu. Use `surface-container-low` with a vertical "active" indicator: a 3px wide rounded pill of `primary` anchored to the left, paired with a subtle `surface-container-highest` background for the active row.

---

## 6. Do’s and Don’ts

### Do:
- **Embrace White Space:** If a section feels crowded, double the padding before you consider adding a border.
- **Layer Tones:** Use `surface-container-lowest` for your most important interactive elements.
- **Subtle Motion:** Use `200ms cubic-bezier(0.4, 0, 0.2, 1)` for all hover transitions to mimic a high-end, responsive feel.

### Don’t:
- **Don’t use 100% Black:** Always use `on-surface` (#191C1D) for text to maintain visual softness.
- **Don’t use Standard Grids:** Occasionally break the grid by having an image or a code block "bleed" into the sidebar area or use asymmetrical margins (e.g., 64px left, 48px right) for a signature look.
- **No Heavy Borders:** If you feel the urge to add a border, try a 1px background color shift instead.